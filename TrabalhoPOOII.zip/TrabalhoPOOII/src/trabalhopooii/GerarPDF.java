package trabalhopooii;

import java.io.FileOutputStream;
import java.io.IOException;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;
import java.util.List;

public class GerarPDF {

    public void Gerar(List<Imovel> lista) {
        Document document = new Document();
        try {
            PdfWriter.getInstance(document, new FileOutputStream("C:\\Temp\\TrabalhoPOOII.pdf"));
            document.open();
            for(Imovel i: lista){
                String args = (i.getTipo()+i.getEndereco()+i.getBairro()+i.getArea()+i.getQuartos()+i.getValor());
                document.add(new Paragraph(args));
            }
        } catch(DocumentException | IOException de) {
            System.err.println(de.getMessage());
        }document.close();
    }   
}
