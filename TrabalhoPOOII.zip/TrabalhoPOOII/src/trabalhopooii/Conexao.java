package trabalhopooii;


import java.sql.Connection;
import java.sql.DriverManager;

public class Conexao {
    
    public static  Connection Conectar(){
        try {
            Class.forName("com.mysql.jdbc.Driver");
            return DriverManager.getConnection("jdbc:mysql://localhost:3306/trabalho?" + "user=root&password=");
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
            return null;
        }
    }
}
