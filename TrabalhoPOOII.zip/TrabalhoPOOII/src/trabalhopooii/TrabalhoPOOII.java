package trabalhopooii;

public class TrabalhoPOOII {

    public static void main(String[] args) {
        new Autenticar().setVisible(true); 
    }
    
}
