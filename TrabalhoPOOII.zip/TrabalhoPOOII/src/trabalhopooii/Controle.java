/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package trabalhopooii;

import java.sql.*;
import java.util.ArrayList;

/**
 *
 * @author Thiago
 */
public class Controle {

    Connection con;

    public String Autenticar(String user, String pass) {
        String cargo = "";
        try {
            String sql = "SELECT cargo from acesso" + " where usuario=? and " + " senha=?;";
            con = Conexao.Conectar();
            PreparedStatement stm = con.prepareStatement(sql);
            stm.setString(1, user);
            stm.setString(2, pass);
            ResultSet rs = stm.executeQuery();
            while(rs.next())
                cargo = rs.getString("cargo");
            con.close();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return cargo;
    }
    
        public Controle(){
        con = Conexao.Conectar();
    }
    
     public ArrayList<Funcionario> buscaDados(String consulta) {
        ArrayList<Funcionario> list = null;
        try {
            String query;
            Statement stm = con.createStatement();            
            if (consulta.isEmpty() ==  true) {
                query = "select * from acesso";
            } else {
                query = "select * from acesso where cargo like" + " '%" + consulta + "%' ";
            }ResultSet rs = stm.executeQuery(query);
            list = new ArrayList<>();  //instanciado ArrayList pelo objeto list
            while (rs.next()) {
                Funcionario f = new Funcionario();
                f.setId(String.valueOf(rs.getInt("id")));
                f.setNome(rs.getString("nome"));
                f.setCargo(rs.getString("cargo"));
                list.add(f);
            }
            rs.close();
            stm.close();
            con.close();
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
        return list;
    }
     
    public ArrayList<Imovel> buscaDados2(String consulta) {
        ArrayList<Imovel> list = null;
        try {
            String query;
            Statement stm = con.createStatement();            
            if (consulta.isEmpty() ==  true) {
                query = "select * from imovel";
            } else {
                query = "select * from imovel where tipo like" + " '%" + consulta + "%' ";
            }ResultSet rs = stm.executeQuery(query);
            list = new ArrayList<>();  //instanciado ArrayList pelo objeto list
            while (rs.next()) {
                Imovel i = new Imovel();
                i.setId(rs.getInt("id"));
                i.setTipo(rs.getString("tipo"));
                i.setEndereco(rs.getString("endereco"));
                i.setBairro(rs.getString("bairro"));
                i.setArea(rs.getString("area"));
                i.setQuartos(rs.getString("quartos"));
                i.setValor(rs.getString("valor"));
                list.add(i);
            }
            rs.close();
            stm.close();
            con.close();
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
        return list;
    }
}
