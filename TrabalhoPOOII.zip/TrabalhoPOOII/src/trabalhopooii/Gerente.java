package trabalhopooii;

import java.util.List;

public class Gerente extends Funcionario {
    
    public void AlterarAtendente(int Id, String name, String user, String password, String cargo, AcessoJpaController c){
        Acesso a = new Acesso();
        a.setId(Id);
        a.setNome(name);
        a.setUsuario(user);
        a.setSenha(password);
        a.setCargo("Atendente");
        try {
            c.edit(a);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    public void CriarAtendente(String name, String user, String password, String cargo, AcessoJpaController c){
        Acesso a = new Acesso();
        a.setNome(name);
        a.setUsuario(user);
        a.setSenha(password);
        a.setCargo(cargo);
        try {
            c.create(a);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    public void ExcluirAtendente(int Id, List<Acesso> lista, AcessoJpaController c){
        if (lista != null) {
            try {
                c.destroy(Id);
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }
}
